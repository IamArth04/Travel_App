package com.example.app_travel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
